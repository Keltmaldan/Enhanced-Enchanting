package net.mcreator.enhancedenchanting.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.enhancedenchanting.world.inventory.EnchantmentsUpgraderGUIMenu;
import net.mcreator.enhancedenchanting.network.EnchantmentsUpgraderGUIButtonMessage;
import net.mcreator.enhancedenchanting.init.EnhancedEnchantingModScreens;

import com.mojang.blaze3d.systems.RenderSystem;

public class EnchantmentsUpgraderGUIScreen extends AbstractContainerScreen<EnchantmentsUpgraderGUIMenu> implements EnhancedEnchantingModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_upgrade;
	private static final ResourceLocation BACKGROUND = ResourceLocation.parse("enhanced_enchanting:textures/screens/enchantments_upgrader_gui.png");

	public EnchantmentsUpgraderGUIScreen(EnchantmentsUpgraderGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 174;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
	}

	@Override
	public void init() {
		super.init();
		button_upgrade = Button.builder(Component.translatable("gui.enhanced_enchanting.enchantments_upgrader_gui.button_upgrade"), e -> {
			int x = EnchantmentsUpgraderGUIScreen.this.x;
			int y = EnchantmentsUpgraderGUIScreen.this.y;
			if (true) {
				PacketDistributor.sendToServer(new EnchantmentsUpgraderGUIButtonMessage(0, x, y, z));
				EnchantmentsUpgraderGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 61, this.topPos + 70, 54, 20).build();
		this.addRenderableWidget(button_upgrade);
	}
}